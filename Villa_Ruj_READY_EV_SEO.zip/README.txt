Villa Ruj website — gotov statički sajt za Netlify.
Glavni fajl: index.html
Za izmenu slika: assets/

Booking links: Airbnb + email (villarujretreat@gmail.com). No phone number is included on the site.
