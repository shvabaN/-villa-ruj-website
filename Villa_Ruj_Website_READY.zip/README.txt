Villa Ruj website — gotov statički sajt za Netlify.
Glavni fajl: index.html
Za izmenu slika: assets/
